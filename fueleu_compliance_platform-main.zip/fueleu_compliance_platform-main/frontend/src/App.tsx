// src/App.tsx
import React from "react";
import AppRouter from "./adapters/ui/AppRouter";

export default function App() {
  return <AppRouter />;
}
