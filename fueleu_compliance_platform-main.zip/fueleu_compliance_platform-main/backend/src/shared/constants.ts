export const TARGET_INTENSITY = 89.3368; // gCO2e / MJ
export const ENERGY_FACTOR_MJ_PER_T = 41000; // MJ per tonne
export const GRAMS_PER_TONNE = 1_000_000;
